"""Utilizado para cálculos simples com dois elementos e uma única operação"""

