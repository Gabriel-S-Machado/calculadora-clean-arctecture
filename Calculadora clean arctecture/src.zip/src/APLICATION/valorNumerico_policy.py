def value_policy(self, valor_novo: float):
        """
        Verifica se o valor de entrada segue as politicas de
        """
        if not type(valor_novo, (float, int, str)):
            raise TypeError(f"entrada '{valor_novo}' não poderia ser do tipo '{type(valor_novo)}'")
        
        if type(valor_novo, int):
            return float(valor_novo)
        elif type(valor_novo, str):
            return float(valor_novo.replace(",", "."))
        else: return valor_novo