# ORDEM DE CALCULO PYTHON
"""
print(10-5)
"""

# LIST.POP
"""
l = [1, 2, 3]
l.pop(0)
print(l)
"""

# ACESSO DICT
"""

class tmp: 
    def __init__(self, a, b):
        self.a = a
        self.b = b

t = tmp(1, 2)

print(t.__dict__)
"""